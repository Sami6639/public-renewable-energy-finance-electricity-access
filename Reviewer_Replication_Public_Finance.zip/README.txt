Public Renewable Energy Finance and Electricity Access: A Global Comparison by Income Group

Reproduction
Unzip the entire archive. Run with Python 3.10+ from the extracted directory:
  python -m pip install -r requirements.txt
  python analyse.py
  python figures.py

The public run rebuilds country-year observations, approval selection, instrument links, objective comparisons and sensitivity results. The two aggregate market tables shipped in results/ permit public regeneration of the three figures. To recalculate transaction aggregates, install pyarrow and run:
  python analyse.py /path/to/Project_Finance_2000_2025.parquet
  python figures.py
Only the licensed run rebuilds market.csv and broad_market.csv. Individual LSEG records are not distributed.

Country inputs, frozen 25 November 2026
IRENASTAT PUBFIN_2026_H2_PX (September 2026, million constant 2023 USD):
https://pxweb.irena.org/api/v1/en/IRENASTAT/Finance/PUBFIN_2026_H2_PX.px
All economies, technologies and years were requested in json-stat2 format. The code sums 13 eligible renewable categories, preserving missing totals and numerical zero. Regional and unallocated amounts enter only the published world-total validation (2015–2024). The analysis population excludes regional aggregates.
WDI EG.ELC.ACCS.ZS and SP.POP.TOTL:
https://api.worldbank.org/v2/country/all/indicator/EG.ELC.ACCS.ZS?date=2000:2024&format=json&per_page=20000
https://api.worldbank.org/v2/country/all/indicator/SP.POP.TOTL?date=2000:2024&format=json&per_page=20000
Income groups: World Bank historical classifications, July 2026, archived at
https://catalog.ourworldindata.org/meadow/wb/2026-07-01/income_groups/income_groups.parquet
Source workbook: https://ddh-openapi.worldbank.org/resources/DR0095334/download
The input classification year is the GNI observation year. Calendar t uses the fiscal year ending in t (GNI observation t-2). A missing base-year classification excludes the economy from both arms of the fixed-membership comparison.

World Bank operations, 2014–2024
inputs/approvals/ stores annual Projects API responses (one file per page of up to 200 records). Query https://search.worldbank.org/api/v2/projects with format=json, strdate=YYYY-01-01, enddate=YYYY-12-31, rows=200 and os=0,200,... . Fields: id,project_name,boardapprovaldate,sector,countrycode,prodline,idacommamt,ibrdcommamt,status,totalamt,lendinginstr,supplementprojectflg,project_abstract. Source selection checks unique IDs and the provider's year-specific totals.
bank.py harmonises country codes and screens the product line, status, financing, class and technology. A regional recipient cannot be allocated to individual members. A project with no sector entry is investigated through both of the following public sources.
  (1) https://search.worldbank.org/api/v2/wds?format=json&projectid=P174576&rows=6&fl=projectid,subsc,docdt,guid,url,docty,txturl,display_title (replace the project ID). Only records attributed to that project and dated by the cutoff enter. The subsc field supplies technology labels.
  (2) World Bank IATI publications, country XML from https://bulk-data.iatistandard.org/worldbank/worldbank-gw.xml (replace gw with the lower-case recipient code). Match iati-identifier 44000-Pxxxxxx, sector vocabulary 99. Source addresses, publication timestamps and retained labels/codes are in inputs/sector_evidence.json. Labels may differ across sources and taxonomies. Where the primary sector list is available it defines the screen. Where it is absent, a renewable technology recorded by either supplementary source qualifies. For missing classifications, an explicit renewable investment objective in an official approval document may qualify. Follow-up links are in sector_followup.csv. Records without sufficient sector evidence retain the unresolved flag. These records enter the conditional IDA sensitivity bounds, not the main sample.
The frozen IDA and IBRD financial statements are October 31, 2026 snapshots. inputs/finance_statements.csv retains the agreement ID, parent project, board date, original USD principal, financing window, project name and snapshot date for all instruments in the two statements with board approval during 2014–2024. Public APIs:
https://datacatalogapi.worldbank.org/dexapps/fone/api/apiservice?datasetId=DS00001&resourceId=RS00001&top=16000&type=json
https://datacatalogapi.worldbank.org/dexapps/fone/api/apiservice?datasetId=DS00047&resourceId=RS00049&top=18000&type=json
The screen checks for matching financial instruments even when the projects index reports zero financing. For selected operations it reconstructs both windows exclusively from original principal in the financial statements. Parent identifiers and the date exception are in agreement_links.csv. The final agreement table asserts that no instrument is used twice. Documented exceptions are explained in financial_sources.csv.
inputs/decisions.csv records each approval's broad category, electricity-specific decision, evidence or short documentary summary, evidence type and official URL. It enters the analysis only after independent construction of the eligible register. Broad access includes expansion of electricity services. A sensitivity moves the three Rwanda service-expansion DPOs into Other. IDA-only bounds allocate all unresolved IDA amounts by income and portfolio in the combinations that minimise or maximise the value contrast. Bounds are conditional on amounts in these records.
For the four original 2024 records, short objective descriptions are documentary summaries. Sources may report the region-wide objective of a multiphase programme. Where that differs in specificity, the record for the country operation supplies the decision. Amounts are nominal full approvals, not component budgets.

Output map
Table 1: country_years.csv, operations.csv, broad_market.csv and market.csv
Table 2 and Figure 1: benchmarks.csv and annual.csv
Table 3 and Figure 2: objectives.csv, strict.csv and operations.csv
Table 4 and Figure 3: market.csv and broad_market.csv
Supplement A1–A2: benchmarks.csv, period_checks.csv, country_years.csv and tipping.csv
Supplement B1–B4: approval_flow.csv, approval_screen.csv, financing_agreements.csv, ida_categories.csv, ida_sensitivity.csv, unresolved_bounds.csv, operations.csv, objectives.csv and strict.csv
Supplement C1: broad_market.csv and market.csv
Country and IDA deletion results are in deletions.csv and ida_deletions.csv. All gaps use unrounded shares. Public finance values in country_years.csv are in million constant 2023 USD; approval amounts and original principals are in nominal USD. Costs in market.csv are in recorded USD millions. Percentages are in percentage points on a 0–100 scale.
The market screen uses positive scalar USD-million costs, a unique Deal PermID and the sector/name/financing-date rules in analyse.py. The public and market amounts have different financial meanings. Quantiles use linear interpolation.
checksums.json lists SHA-256 digests of the original package contents. To verify immediately after extracting, run python verify.py. Running the analysis in another library version can change CSV serialisation or image rendering while preserving the underlying values.
