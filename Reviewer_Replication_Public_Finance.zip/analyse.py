from pathlib import Path
import json,sys,unicodedata
import numpy as np,pandas as pd
root=Path(__file__).resolve().parent; src=root/'inputs'; out=root/'results';out.mkdir(exist_ok=True)
def load(name):return json.loads((src/name).read_text())
def indicator(name,field):
    return pd.DataFrame([(r['countryiso3code'],int(r['date']),r['value'],r['country']['value']) for r in load(name)[1] if r['countryiso3code']],columns=['iso','year',field,'name'])
groups=['Low income','Lower middle income','Upper middle income','High income']
hist=pd.read_csv(src/'historical_classes.csv')
inc=hist.rename(columns={'country_code':'iso'}).copy()
inc['year']=inc.year+2  # FY ending in t uses GNI in t-2; known by January of t.
inc['group']=inc.classification.str.strip().map(dict(zip(['L','LM','UM','H'],groups)))
inc=inc.loc[inc.year.between(2000,2024),['iso','year','group']].dropna()
assert not inc.duplicated(['iso','year']).any()
base=inc.merge(indicator('access.json','access'),on=['iso','year']).merge(indicator('population.json','pop').drop(columns='name'),on=['iso','year']);base=base.dropna().copy();base['unserved']=base['pop']*(1-base.access/100)
j=load('irena_2026.json');dim=j['dimension'];axes=[sorted(dim[k]['category']['index'],key=dim[k]['category']['index'].get) for k in j['id']]
tech=dim['Technology']['category']['label']; valid={'Renewable hydropower','Solar photovoltaic','Multiple renewables','Solid biofuels','Wind energy','Liquid biofuels','Onshore wind energy','Geothermal energy','Solar thermal energy','Marine energy','Gas biofuels','Offshore wind energy','Renewable waste'}
assert valid<=set(tech.values())
raw=pd.DataFrame({'fin':j['value']},index=pd.MultiIndex.from_product(axes,names=['iso','tech','year'])).reset_index()
raw.year=raw.year.map(dim['Year']['category']['label']).astype(int)
fin=raw[raw.tech.map(tech).isin(valid)].groupby(['iso','year']).fin.sum(min_count=1).rename('fin').reset_index()
pdf=np.array([17550.29,33482.13,27388.72,21364.99,17228.08,15500,16187.46,24729.37,25194.19,25590.09])
assert max(abs(fin.groupby('year').fin.sum().loc[2015:2024].values-pdf))<.15
base=base.merge(fin,on=['iso','year'],how='left');ob=base.dropna(subset=['fin']).copy();fields=['fin','pop','unserved']
def shares(z):return 100*z.groupby('group')[fields].sum()/z[fields].sum()
def both(z):
    return z[z.iso.isin(z.groupby('iso').year.nunique().loc[lambda x:x==25].index)]
sets={'Full':ob,'Early':ob[ob.year<=2014],'Late':ob[ob.year>=2015],'Balanced':both(ob)}
for k,z in list(sets.items())[1:3]:
    sets[k+' balanced']=z[z.iso.isin(sets['Balanced'].iso)]
fixed=ob.merge(inc[inc.year==2000][['iso','group']].rename(columns={'group':'fixed'}),on='iso')
sets['Early comparable']=fixed[fixed.year<=2014];sets['Late comparable']=fixed[fixed.year>=2015];sets['Fixed comparable']=fixed;sets['Fixed 2000']=fixed.assign(group=fixed.fixed)
pd.concat([shares(z).assign(sample=k,n=len(z),countries=z.iso.nunique()) for k,z in sets.items()]).to_csv(out/'benchmarks.csv')
pd.concat([shares(z).assign(year=y) for y,z in ob.groupby('year')]).to_csv(out/'annual.csv')
pd.DataFrame([dict(omit=i,**shares(ob[ob.iso!=i]).loc['Low income'].to_dict()) for i in ob.iso.unique()]).to_csv(out/'deletions.csv',index=False)
base.to_csv(out/'country_years.csv',index=False)
from bank import bank_sample
ops=bank_sample(src,out,inc,load('population.json')[1])
def objective(z,field):
 a=z.assign(low=z.group.eq(groups[0]),lowamt=z.amount*z.group.eq(groups[0])).groupby(field).agg(n=('id','size'),low_n=('low','sum'),amount=('amount','sum'),lowamt=('lowamt','sum'));a['share']=100*a.lowamt/a.amount;return a
ida=ops[ops.window=='IDA'];common=ida.groupby('country_code').objective_class.nunique().loc[lambda x:x==2].index
pd.concat([objective(z,'objective_class').assign(sample=k) for k,z in [('All',ops),*list(ops.groupby('window')),('Shared',ida[ida.country_code.isin(common)]),('Early IDA',ida[ida.year<=2018]),('Late IDA',ida[ida.year>2018])]]).to_csv(out/'objectives.csv');objective(ida,'strict').to_csv(out/'strict.csv')
if len(sys.argv)>1:
 deals=pd.read_parquet(sys.argv[1]);assert deals['Deal PermID'].is_unique
 deals['year']=pd.to_datetime(deals['Financed Date'],format='ISO8601',errors='coerce').dt.year
 names=deals['Project Name'].fillna('');z=deals[deals.year.between(2000,2024)&deals['Project Industry Sector Code'].str.fullmatch(r'Power(?:\|Power)*',na=False)&names.str.contains(r'\b(?:solar|photovoltaic|wind|windfarm|windpark)\b',case=False)&~names.str.contains(r'\b(?:coal|gas|oil|diesel|transmission|refinanc\w*)\b',case=False)].copy()
 def norm(s):return ''.join(c for c in unicodedata.normalize('NFKD',str(s)).lower() if c.isascii() and c.isalnum())
 codes={norm(r['country']['value']):r['countryiso3code'] for r in load('population.json')[1] if r['countryiso3code']}
 codes.update(dict(chinamainland='CHN',czechrepublic='CZE',palestinianterritories='PSE',unitedstatesofamerica='USA',southkorea='KOR',vietnam='VNM',puertorico='PRI',taiwan='TWN',turkey='TUR',egypt='EGY',russia='RUS',laos='LAO'))
 z['iso']=z['Project Nation'].map(lambda x:codes.get(norm(x)));q=z.merge(inc,on=['iso','year']);m=q.merge(ob[['iso','year','fin']],on=['iso','year']);m['cost']=pd.to_numeric(m['Total Project Cost'],errors='coerce').where(m['Amount Currency'].eq('USD')&m['Amount Scale'].eq('millions'));good=m[m.cost.gt(0)&np.isfinite(m.cost)]
 def market(x):
    t=x.groupby('group').cost.agg(deals='size',total='sum',mean='mean',median='median',q25=lambda y:y.quantile(.25),q75=lambda y:y.quantile(.75));cells=x.drop_duplicates(['iso','year']);t['cells']=cells.groupby('group').size();t['count_share']=100*t.deals/t.deals.sum();t['cost_share']=100*t.total/t.total.sum();t['public_share']=100*cells.groupby('group').fin.sum()/cells.fin.sum();return t
 pd.concat([market(x).assign(sample=k) for k,x in [('Matched',good),('Omit largest',good.drop(good.cost.idxmax()))]]).to_csv(out/'market.csv')
 q.groupby('group').size().rename('deals').to_csv(out/'broad_market.csv')
 print('screen/classified/matched/priced',len(z),len(q),len(m),len(good),'unmapped',z[z.iso.isna()]['Project Nation'].unique())
F=ob.fin.sum(); L=ob.loc[ob.group==groups[0],'fin'].sum()
low=base.group.eq(groups[0]); missing=int((low&base.fin.isna()).sum())
tips=[]
for f in ['pop','unserved']:
    target=base.loc[low,f].sum()/base[f].sum();extra=(target*F-L)/(1-target)
    tips.append(dict(target=f,share=100*target,missing=missing,per_cell=extra/missing,multiple=extra/missing/base.loc[low,'fin'].mean()))
pd.DataFrame(tips).to_csv(out/'tipping.csv',index=False)
extra_sets={'2014–2023, updated source':ob[ob.year.between(2014,2023)]}
for k,m in [('Early',fixed.year<=2014),('Late',fixed.year>=2015)]:
 extra_sets[k+' fixed']=fixed[m].assign(group=fixed[m].fixed)
pd.concat([shares(z).assign(sample=k,n=len(z),countries=z.iso.nunique()) for k,z in extra_sets.items()]).to_csv(out/'period_checks.csv')
audit=[]
for iso in ida.country_code.unique():
 t=objective(ida[ida.country_code!=iso],'objective_class');audit.append(dict(omit=iso,gap=t.loc['Access','share']-t.loc['Other','share']))
pd.DataFrame(audit).to_csv(out/'ida_deletions.csv',index=False)
# Audit tables used in the supplement.
screen=pd.read_csv(out/'approval_screen.csv')
eligible=screen.status.isin(['Included','Unresolved sector','Sector fields contain no eligible technology'])
flow=screen.assign(eligible=eligible,sector_available=screen.api_sector & eligible,
                   included=screen.status.eq('Included'),unresolved=screen.status.eq('Unresolved sector'))
yearly=flow.groupby('year').agg(inventory=('id','size'),eligible=('eligible','sum'),primary_sector=('sector_available','sum'),included=('included','sum'),unresolved=('unresolved','sum'))
yearly.to_csv(out/'approval_flow.csv')
part=ida.assign(category=np.select([ida.strict,ida.objective_class.eq('Access')],['Electricity-specific','Broader only'],default='Other'))
objective(part,'category').to_csv(out/'ida_categories.csv')
def comparison(frame, label):
    t=objective(frame,'objective_class')
    a=t.loc['Access']; b=t.loc['Other']
    return dict(sample=label,access_n=a.n,other_n=b.n,access_share=a.share,other_share=b.share,gap=a.share-b.share)
checks=[comparison(ida,'All IDA'),comparison(ida[ida.api_sector],'Primary sector field available'),
        comparison(ida[~ida.additional],'Excluding flagged additional financing'),
        comparison(ida[ida.year<2024],'Through 2023'),
        comparison(ida[ida.instrument=='Investment Project Financing'],'Investment project financing')]
general={'P162671','P166458','P169040'}
checks.append(comparison(ida.assign(objective_class=ida.objective_class.mask(ida.id.isin(general),'Other')),'General electricity-service expansion moved to Other'))
pd.DataFrame(checks).to_csv(out/'ida_sensitivity.csv',index=False)
unknown=screen[screen.status.eq('Unresolved sector') & screen.window.eq('IDA')]
bounds=[]
for category, field, positive in [('Broad','objective_class','Access'),('Electricity-specific','strict',True)]:
    for direction in ['Lower','Upper']:
        pos=unknown.group.ne('Low income') if direction=='Lower' else unknown.group.eq('Low income')
        add=unknown.assign(objective_class=np.where(pos,'Access','Other'))
        tagged=ida.assign(objective_class=np.where(ida[field].eq(positive),'Access','Other'))
        bounds.append(comparison(pd.concat([tagged,add]),category+' '+direction))
pd.DataFrame(bounds).to_csv(out/'unresolved_bounds.csv',index=False)
