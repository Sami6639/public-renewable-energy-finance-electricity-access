"""Screen every dated World Bank approval and reconstruct the financing and objective portfolios."""
from pathlib import Path
import json
import pandas as pd

def bank_sample(src, out, income, population):
    inventory = {}
    for year in range(2014, 2025):
        records = {}
        for page in sorted((src / 'approvals').glob(f'{year}-*.json')):
            data = json.loads(page.read_bytes())
            batch = {k:v for k,v in data['projects'].items() if k.startswith('P')}
            assert not records.keys() & batch.keys()
            records.update(batch)
        assert len(records) == int(data['total'])
        assert not inventory.keys() & records.keys()
        inventory.update(records)
    assert len(inventory) == 3571
    mapping = {v['country']['id']: v['countryiso3code'] for v in population if v['countryiso3code']}
    mapping.update(ZR='COD', YF='SRB', RY='YEM', TP='TLS', GZ='PSE', KV='XKX')
    classes = income.set_index(['iso','year']).group.to_dict()
    evidence = json.loads((src / 'sector_evidence.json').read_bytes())
    crosswalk = {'Energy Generation - '+tech for tech in ['Solar','Wind','Hydro','Geothermal','Biomass']}
    decisions = pd.read_csv(src/'decisions.csv')
    statements = pd.read_csv(src/'finance_statements.csv')
    exact = statements.groupby(['project_id','date','window']).principal.sum().to_dict()
    attachments = pd.read_csv(src/'agreement_links.csv').set_index('id').to_dict('index')
    agreements = []
    records = []
    def amount(v):
        return float(str(v or 0).replace(',',''))
    for key, project in sorted(inventory.items()):
        year = int(project['boardapprovaldate'][:4])
        recipient = project.get('countrycode', [])
        iso = mapping.get(recipient[0]) if len(recipient)==1 else None
        group = classes.get((iso,year))
        ida = amount(project.get('idacommamt'))
        ibrd = amount(project.get('ibrdcommamt'))
        date = project['boardapprovaldate'][:10]
        if ida + ibrd == 0:
            ida = exact.get((key,date,'IDA'),0)
            ibrd = exact.get((key,date,'IBRD'),0)
        tags = [v['Name'] for v in project.get('sector',[]) or []]
        source = 'Projects API' if tags else 'No sector field'
        api_sector = bool(tags)
        if not tags and key in evidence:
            fallback = evidence[key]
            ds = [s.strip() for d in fallback['documents'] for s in d['sectors'].split(',')]
            it = [v['name'] for v in fallback['iati'].get('sectors',[])]
            tags = ds + it
            if tags:
                source = 'Documents and IATI' if ds and it else ('Documents' if ds else 'IATI')
        tags = sorted({s.removeprefix('FY17 - ') for s in tags})
        renewable = any(s.startswith('Renewable Energy') or s in crosswalk for s in tags)
        if key=='P181584':
            # Board announcement and financing paper supersede the project index.
            renewable = True
            source = 'Approval document'
        if key=='P504421':
            # The signed agreement finances the operation solely through ESMAP TF0C5865.
            ida = 0
        if renewable and pd.notna(group) and project.get('prodline')=='PE' and project.get('status','').lower() not in ('cancelled','dropped') and ida+ibrd>0:
            link = attachments.get(key,{})
            lookup = link.get('ledger_id',key)
            when = link.get('ledger_date',date)
            if pd.isna(when):
                when = date
            matched = statements[(statements.project_id==lookup) & (statements.date==when) & (statements.principal>0)].copy()
            assert not matched.empty, key
            matched['approval_id'] = key
            agreements.append(matched)
            ida = matched.loc[matched.window=='IDA','principal'].sum()
            ibrd = matched.loc[matched.window=='IBRD','principal'].sum()
        if project.get('prodline')!='PE' or project.get('status','').lower() in ('cancelled','dropped'):
            status = 'Outside lending product/status'
        elif ida + ibrd <= 0:
            status = 'No eligible IDA or IBRD amount'
        elif pd.isna(group):
            status = 'No single historically classified economy'
        elif renewable:
            status = 'Included'
        elif tags:
            status = 'Sector fields contain no eligible technology'
        else:
            status = 'Unresolved sector'
        records.append(dict(id=key,title=project['project_name'],year=year,country_code=iso,group=group,
            amount=ida+ibrd,ida=ida,ibrd=ibrd,window=('Mixed' if ida and ibrd else ('IDA' if ida else 'IBRD')) if ida+ibrd else '',
            instrument=project.get('lendinginstr'),additional=project.get('supplementprojectflg')=='Y',
            api_sector=api_sector,sector_source=source,sector=' | '.join(tags),status=status))
    confirmed = pd.concat(agreements,ignore_index=True)
    assert confirmed.agreement.is_unique
    confirmed.to_csv(out/'financing_agreements.csv',index=False)
    frame = pd.DataFrame(records)
    frame.to_csv(out/'approval_screen.csv',index=False)
    included = frame[frame.status.eq('Included')].copy()
    assert set(included.id)==set(decisions.id)
    ops = included.merge(decisions,on='id',validate='one_to_one')
    assert not ops.loc[ops.strict,'objective_class'].ne('Access').any()
    ops.to_csv(out/'operations.csv',index=False)
    return ops
