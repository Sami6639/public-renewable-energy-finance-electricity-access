from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
out=Path(__file__).resolve().parent/'results'
plt.rcParams.update({'font.size':10,'axes.spines.right':False,'axes.spines.top':False})
green,blue,orange='#007768','#244B70','#A44515'
def save(fig,n):
    fig.tight_layout();fig.savefig(out/f'figure{n}.png',dpi=270,bbox_inches='tight');plt.close(fig)
a=pd.read_csv(out/'annual.csv').query("group=='Low income'")
fig,ax=plt.subplots(figsize=(6.6,2.7))
for f,l,c,m in [('unserved','Without electricity',green,'o'),('pop','Population',blue,'s'),('fin','Commitments',orange,'^')]:ax.plot(a.year,a[f],label=l,color=c,marker=m,ms=2.6)
ax.set(xticks=range(2000,2025,4),ylim=(0,100),ylabel='Low-income share');ax.yaxis.set_major_formatter(PercentFormatter(100,0));ax.legend(loc='upper center',bbox_to_anchor=(.5,1.22),ncol=3,frameon=False);save(fig,1)
obj=pd.read_csv(out/'objectives.csv');wide=obj[obj['sample']=='IDA'].set_index('objective_class').loc[['Other','Access']];shared=obj[obj['sample']=='Shared'].set_index('objective_class').loc[['Other','Access']];strict=pd.read_csv(out/'strict.csv').sort_values('strict')
fig,ax=plt.subplots(figsize=(6.6,2.6))
for y,v in enumerate([wide.share,100*wide.low_n/wide.n,shared.share,strict.share]):
    l,h=v.tolist();ax.plot([l,h],[y,y],color='gray',lw=1.4)
    for x,col,mark,label in [(l,blue,'s','Comparison'),(h,green,'o','Access')]:
        ax.scatter(x,y,color=col,marker=mark,label=label if y==0 else None);ax.text(x,y-.16,f'{x:.1f}',ha='center',fontsize=9)
ax.set(xlim=(0,100),ylim=(3.5,-.55),yticks=range(4),yticklabels=['Broad · value','Broad · count','Shared recipients · value','Electricity-specific · value'],xlabel='Low-income share (%)');ax.legend(loc='upper center',bbox_to_anchor=(.5,1.22),ncol=2,frameon=False);save(fig,2)
b=pd.read_csv(out/'broad_market.csv').set_index('group').deals;t=pd.read_csv(out/'market.csv').query("sample=='Matched' and group=='High income'").iloc[0];fig,ax=plt.subplots(figsize=(6.5,2.1));v=[100*b['High income']/b.sum(),t.count_share,t.cost_share];bars=ax.barh([2,1,0],v,color=[blue,blue,orange],height=.5);ax.bar_label(bars,labels=[f'{x:.1f}%' for x in v],padding=4);ax.set(xlim=(0,100),yticks=[2,1,0],yticklabels=['All classified · count','Shared cells · count','Shared cells · cost'],xlabel='High-income share');ax.xaxis.set_major_formatter(PercentFormatter(100,0));save(fig,3)
